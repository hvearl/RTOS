#include "Aperiodic.h"

Aperiodic::Aperiodic(char task_ID, int e, int p) : Task(task_ID, e, p + 500), release_time(p), first_deadline(p + 500), Complete(false), Miss(false) {}
