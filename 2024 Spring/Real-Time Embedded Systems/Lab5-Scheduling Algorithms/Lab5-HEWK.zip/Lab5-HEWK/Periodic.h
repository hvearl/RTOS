#ifndef PERIODIC_H
#define PERIODIC_H

#include "Task.h"

class Periodic : public Task {
public:
    Periodic(char task_ID, int e, int p);
};

#endif
