#ifndef TASK_H
#define TASK_H

#include <iostream>
#include <vector>

class Task {
public:
    char task_ID;
    int exec_time;
    int period;
    int next_deadline;
    int slack;

    Task(char id, int e, int d);
    virtual ~Task();
};

#endif
