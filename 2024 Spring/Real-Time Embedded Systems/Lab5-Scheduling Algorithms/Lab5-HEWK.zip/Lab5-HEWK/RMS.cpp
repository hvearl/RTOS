/*
The following file contains functions pertaining to Rate Monotonic Analysis simulations.


*/
#include "RMS.h"
#include <vector>
void RMS_Prioritize(vector<Periodic>& tasks) {
	sort(tasks.begin(), tasks.end(), [](const Periodic& a, const Periodic& b) {
		return a.period < b.period;
		});
}

void Sort_Atasks(vector<Aperiodic>& A_tasks) {
	sort(A_tasks.begin(), A_tasks.end(), [](const Aperiodic& a, const Aperiodic& b) {
		return a.release_time < b.release_time;
		});
}

void RMS_RUN(vector<Periodic>& tasks,vector<Aperiodic>& a_tasks, int sim_time, char* file) {
	int elapsed_time = 0;
	int current_time=0;
    int current_task_index = 0;
	int a_task_index=0;
	int missed_deadlines=0;
	int preemptions=0;
	
	//for aperiodic
	int sum_wcet=0;
	for(int k=0; k<tasks.size();k++){
		sum_wcet+=tasks[k].exec_time;
	}
	
	//open output file
	ofstream outfile(file);
	if(!outfile.is_open()){
		cout<<"Error opening output file."<<endl;
		exit(1);
	}
	
	outfile<<"Beginning RMA Simulation."<<endl;
	outfile <<elapsed_time<< " ms Running task " << tasks[current_task_index].task_ID <<endl;
	for(;elapsed_time < sim_time; elapsed_time++,current_time++) {
			//check if deadline missed
			//print error message
			//move on to next task
			//aperiodic task analysis
		for(int m = 0; m < a_tasks.size(); m++){ // check that the task has not expired
			if(elapsed_time>a_tasks[m].next_deadline && !a_tasks[m].Complete && !a_tasks[m].Miss){ // add and not complete
				outfile<<elapsed_time<<" ms Task "<<a_tasks[m].task_ID<< " missed its deadline"<<endl;
				a_tasks[m].Miss = true;
				//ADD PREEMPT?
			}
		}
		if(elapsed_time>tasks[current_task_index].next_deadline){
			outfile<<elapsed_time<<" ms Task "<<tasks[current_task_index].task_ID<< " missed a deadline"<<endl<<endl;
			outfile<<"Ending task "<<tasks[current_task_index].task_ID<<endl;
			missed_deadlines++;
			//move on to next task
			tasks[current_task_index].next_deadline+=tasks[current_task_index].period;
			current_time=0;
			current_task_index = (current_task_index + 1) % tasks.size();
			outfile <<elapsed_time<< " ms Running task " << tasks[current_task_index].task_ID<<  endl;
		}
        // Default: Move to the next task (wrap around if necessary)
		if(current_time==tasks[current_task_index].exec_time){
			tasks[current_task_index].next_deadline+=tasks[current_task_index].period;
			current_time=0;
			outfile<<elapsed_time<< " ms Completed task "<<tasks[current_task_index].task_ID<<endl;
			current_task_index = (current_task_index + 1) % tasks.size();
			outfile << elapsed_time<<" ms Running task " << tasks[current_task_index].task_ID << endl;
			
			// aperiodic tasks 
			for (int j = 0; j < a_tasks.size(); j++) { // for each aperiodic task
				if(elapsed_time>a_tasks[a_task_index].release_time && current_task_index + 1 == tasks.size() && a_tasks[a_task_index].Complete == false){
					if((elapsed_time + tasks[current_task_index].exec_time + a_tasks[a_task_index].exec_time) < tasks[0].next_deadline ){ // the task has enough slack to run
						bool not_valid = false;
						for(int k = 0; k < tasks.size(); k++){
							if ((elapsed_time + sum_wcet + a_tasks[a_task_index].exec_time) > tasks[k].next_deadline){
								not_valid = true;
							}
						}
						if(!not_valid && elapsed_time + tasks[current_task_index].exec_time < sim_time){
							outfile <<elapsed_time<< " ms Running in slack task " << a_tasks[a_task_index].task_ID <<endl;
							a_tasks[a_task_index].Complete = true;
							elapsed_time += a_tasks[a_task_index].exec_time;
						}else{
							not_valid = false;
						}
					}
				}
				a_task_index++;
			}
			a_task_index = 0;
		}
	
	}
	//write summary
	outfile<<endl<<"RMS Simulation ended at "<<elapsed_time <<" ms"<<endl;
	outfile<<"Total number of deadline misses: "<<missed_deadlines<<endl;
	outfile<<"Total number of preemptions: "<<preemptions<<endl<<endl<<endl<<endl<<endl;
	
	//close output file
	outfile.close();
}
