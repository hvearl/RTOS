#include "Task.h"
#include "Periodic.h"
#include "Aperiodic.h"
#include "RMS.h"
#include "EDF.h"
#include "LLF.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <thread>
#include <chrono>

using namespace std;
int main(int argc, char *argv[]){
	if(argc!=3){
		printf("Error: Invalid number of command-line arguments. %d given. Please try again.", argc);
		exit(1);
	}
	
	ifstream infile(argv[1]);
	if(!infile.is_open()){
		cout<<"Error opening input file."<<endl;
		exit(1);
	}
	
	ofstream outfile(argv[2]);
	if(!outfile.is_open()){
		cout<<"Error opening output file."<<endl;
		exit(1);
	}
	
	int num_tasks;
	string line;
	getline(infile, line);
	istringstream iss(line);
	iss>>num_tasks;
	cout<<"Number of tasks:"<< num_tasks<< endl;
	
	int exec_time;
	getline(infile,line);
	istringstream iss2(line);
	iss2>>exec_time;
	
	//get info from files
	char id;
	char comma;
	int exec_temp, period_temp;
	vector<Periodic> tasks;
	for(int i=0; i<num_tasks;i++){
		infile>>id>>comma>>exec_temp>>comma>>period_temp;
		tasks.emplace_back(id, exec_temp, period_temp);
	}
	int num_async;
	infile>>num_async;
	//create table
	auto tms1 =new int[num_async][2];
	auto ids1 =new char[num_async];
	vector<Aperiodic> a_tasks;
	vector<Aperiodic> a_tasks2;
	for(int i=0; i<num_async;i++){
		infile>>id>>comma>>exec_temp>>comma>>period_temp;
		ids1[i]=id;
		tms1[i][0]=exec_temp;
		tms1[i][1]=period_temp;
		a_tasks.emplace_back(id,exec_temp,period_temp);
		a_tasks2.emplace_back(id,exec_temp,period_temp);
	}
	infile.close();
	RMS_Prioritize(tasks); 
	Sort_Atasks(a_tasks);
	
	cout << "Number of asyncronous tasks:" << num_async << endl;
	cout<<"Execution time:"<<exec_time<<endl;
 //prioritize tasks based on RMS (fixed)
	RMS_RUN(tasks,a_tasks,exec_time,argv[2]);  //run RMS simulation
	cout<<"Finished RMS simulation."<<endl;
	
	vector<Task*>allTasks;
	vector<Task*>allTasks2;
	for(auto& task:tasks){
		allTasks.push_back(&task);
		allTasks2.push_back(&task);
	}
	for(auto& task:a_tasks){
		allTasks.push_back(&task);
	}
	for(auto& task:a_tasks2){
		allTasks2.push_back(&task);
	}

	EDF_Prioritize_first(allTasks);
	EDF_RUN(allTasks,exec_time,argv[2]);
	cout<<"Finished EDF simulation."<<endl;

	LLF_Prioritize_first(allTasks2);
	LLF_RUN(allTasks2,exec_time,argv[2]);
	cout<<"Finished LLF simulation."<<endl;
	return 0;
}

