#include "Periodic.h"

Periodic::Periodic(char task_ID, int e, int p) : Task(task_ID, e, p) {}
