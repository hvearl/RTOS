#include "Task.h"

Task::Task(char id, int e, int d) : task_ID(id), exec_time(e), next_deadline(d), period(d), slack(next_deadline - period) {}

Task::~Task() {}
