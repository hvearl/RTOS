#include "EDF.h"
#include <fstream>
#include <algorithm>

void EDF_Prioritize_first(vector<Task*>& tasks){
	//reset next deadline 
	for(auto& task:tasks){
		task->next_deadline=task->period;
	}
	//reorder
	sort(tasks.begin(), tasks.end(), [](const Task* a, const Task* b) {
		return a->next_deadline < b->next_deadline;
		});

}

int EDF_Sort(vector<Task*>& tasks, ofstream& outfile) {
    int preemptions = 0;
    for (size_t i = 0; i < tasks.size(); ++i) {
        for (size_t j = i + 1; j < tasks.size(); ++j) {
            Aperiodic* aperiodicTaskI = dynamic_cast<Aperiodic*>(tasks[i]);
            Aperiodic* aperiodicTaskJ = dynamic_cast<Aperiodic*>(tasks[j]);
            if (aperiodicTaskI && aperiodicTaskJ) {
                if (!aperiodicTaskI->Complete && !aperiodicTaskJ->Complete) {
                    if (tasks[i]->next_deadline > tasks[j]->next_deadline) {
                        swap(tasks[i], tasks[j]);
                        outfile << "Task " << tasks[i]->task_ID << " has preempted " << tasks[j]->task_ID << std::endl;
                        preemptions++;
							
                    }
					
                }
            } else if (!aperiodicTaskI || !aperiodicTaskJ) {
                if (tasks[i]->next_deadline > tasks[j]->next_deadline) {
                    swap(tasks[i], tasks[j]);
                    outfile << "Task " << tasks[i]->task_ID << " has preempted " << tasks[j]->task_ID << std::endl;
                    preemptions++;
                }
            }
        }
    }
	
    return preemptions;
}

void EDF_RUN(vector<Task*>& tasks, int sim_time, char* file){
	int elapsed_time = 0;
	int current_time=0;
    int current_task_index = 0;
	int missed_deadlines=0;
	int preemptions=0;
	
	ofstream outfile(file,ios_base::app);
	if(!outfile.is_open()){
		cout<<"Error opening output file."<<endl;
		exit(1);
	}
	
	outfile<<"Beginning EDF Simulation."<<endl;
	outfile <<elapsed_time<< " ms Running task " << tasks[current_task_index]->task_ID <<endl;
	for(;elapsed_time < sim_time; elapsed_time++,current_time++) {
        // Run the current task for its execution time
		//re-prioritize based on next deadline
		preemptions=preemptions+EDF_Sort(tasks,outfile);
			//check if deadline missed
			//print error message
			//move on to next task
		if(elapsed_time>tasks[current_task_index]->next_deadline){
			outfile<<elapsed_time<<" ms Task "<<tasks[current_task_index]->task_ID<< " missed a deadline "<<endl<<endl;
			outfile<<"Ending task "<<tasks[current_task_index]->task_ID<<endl;
			missed_deadlines++;
			//move on to next task
			tasks[current_task_index]->next_deadline+=tasks[current_task_index]->period;
			current_time=0;
			current_task_index = (current_task_index + 1) % tasks.size();
			outfile <<elapsed_time<< " ms Starting task " << tasks[current_task_index]->task_ID<< endl;
		}
        // Default: Move to the next task (wrap around if necessary)
		if(current_time==tasks[current_task_index]->exec_time){
			if(dynamic_cast<Aperiodic*>(tasks[current_task_index])){
				dynamic_cast<Aperiodic*>(tasks[current_task_index])->Complete=true;
			}
			outfile<<elapsed_time<< " ms Completed task "<<tasks[current_task_index]->task_ID<<endl;
			// Remove completed aperiodic tasks
			tasks.erase(remove_if(tasks.begin(), tasks.end(), [](Task* t) {
				Aperiodic* aperiodicTask = dynamic_cast<Aperiodic*>(t);
				return aperiodicTask && aperiodicTask->Complete;
			}), tasks.end());
			tasks[current_task_index]->next_deadline+=tasks[current_task_index]->period;
			current_time=0;
			current_task_index = (current_task_index + 1) % tasks.size();
			outfile <<elapsed_time<< " ms Running task " << tasks[current_task_index]->task_ID << endl;
		}
	
	}
	//write summary
	outfile<<endl<<"EDF Simulation ended at "<<elapsed_time<<" ms" <<endl;
	outfile<<"Total number of deadline misses: "<<missed_deadlines<<endl;
	outfile<<"Total number of preemptions: "<<preemptions<<endl<<endl<<endl<<endl<<endl;
	
	//close output file
	outfile.close();
}