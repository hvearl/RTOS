#ifndef APERIODIC_H
#define APERIODIC_H

#include "Task.h"

class Aperiodic : public Task {
public:
    int first_deadline;
    bool Complete;
    bool Miss;
    int release_time;

    Aperiodic(char task_ID, int e, int p);
};

#endif
