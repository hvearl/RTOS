#ifndef LLF_H
#define LLF_H

#include "Task.h"
#include "Aperiodic.h"
#include "Periodic.h"
#include <vector>
#include<algorithm>
#include<fstream>
using namespace std;
void LLF_Prioritize_first(vector<Task*>& tasks);
void slack_update(vector<Task*>& tasks);
int LLF_Sort(vector<Task*>& tasks, ofstream& outfile);
void LLF_RUN(vector<Task*>& tasks, int sim_time, char* file);

#endif
