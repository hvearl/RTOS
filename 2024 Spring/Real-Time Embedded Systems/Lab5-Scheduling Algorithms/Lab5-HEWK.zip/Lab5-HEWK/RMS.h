#ifndef RMS_H
#define RMS_H

#include "Task.h"
#include "Aperiodic.h"
#include "Periodic.h"
#include <vector>
#include<algorithm>
#include<fstream>

using namespace std;
void RMS_Prioritize(vector<Periodic>& tasks);
void RMS_RUN(vector<Periodic>& tasks, vector<Aperiodic>& a_tasks, int sim_time, char* file);
void Sort_Atasks(vector<Aperiodic>& A_tasks);
#endif
