#ifndef EDF_H
#define EDF_H

#include "Task.h"
#include "Aperiodic.h"
#include "Periodic.h"
#include <vector>
#include<algorithm>
#include<fstream>
using namespace std;

void EDF_Prioritize_first(vector<Task*>& tasks);
int EDF_Sort(vector<Task*>& tasks, ofstream& outfile);
void EDF_RUN(vector<Task*>& tasks, int sim_time, char* file);

#endif
